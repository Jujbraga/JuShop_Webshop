<?php include('templates/header.php'); ?>

<section class="about">
    <h2>Golden Grass History</h2>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ut tellus ut magna pharetra aliquam ac eu justo.
        Aenean nec luctus lorem. Etiam nec risus libero. Aenean eu magna semper, porta risus sit amet, maximus nulla.
        Nam sem quam, vulputate in risus quis, consectetur bibendum justo. Vivamus metus neque, dapibus sit amet malesuada
        ac, fermentum nec ex. Donec sit amet tristique metus.</p>
    <div class="video">
      <iframe width="560" height="315" src="https://www.youtube.com/embed/O8fDq3-eRm8" frameborder="0" allowfullscreen></iframe>
    </div>
    <p>Sed varius lobortis tellus et hendrerit. Donec eros nulla, pharetra in est ac, tincidunt tristique elit.
        Suspendisse efficitur dolor sed felis dapibus viverra. Phasellus efficitur, urna eu pellentesque efficitur, leo
        mi posuere ex, tincidunt iaculis tellus neque sit amet urna. Curabitur at blandit mauris. Aenean pulvinar malesuada
        lectus sed sollicitudin. Proin id maximus justo. Vivamus dictum cursus metus vitae dapibus. Aenean gravida, lectus
        a rutrum laoreet, nulla libero vestibulum sem, volutpat posuere sapien massa ut ante. Integer elementum nunc et dui
        fermentum, ac ultricies leo scelerisque. Nullam dapibus efficitur risus, vitae sollicitudin nisl. Vestibulum eu
        dolor in dui placerat tincidunt. Vivamus mauris mauris, dapibus eget aliquet vitae, accumsan vel dolor. Integer
        tincidunt justo sit amet justo accumsan, id lacinia nunc consectetur. Quisque pellentesque lacus posuere euismod
        venenatis. Morbi euismod porttitor elit vitae molestie.</p>
    <p>Vivamus maximus in ligula in vulputate. Aliquam erat volutpat. Nullam accumsan mi ac accumsan rutrum. Morbi ac
        risus imperdiet, blandit mauris in, placerat sem. Mauris nibh orci, gravida ut quam at, pharetra pharetra augue.
        Praesent in molestie lorem, iaculis sagittis leo. Nulla laoreet tempus pellentesque.</p>
  </section>

<?php include("templates/footer.php");?>
