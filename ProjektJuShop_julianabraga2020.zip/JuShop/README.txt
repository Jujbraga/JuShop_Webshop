Instructions:
1. Open the file "database/openfirst/createdb.php" to create the database jushop;
2. Import the attached file "tabel_products.sql" into database, this file already have
   all the products and their pictures.
3. Open the file "database/openfirst/createtable" to create the others tables.
